# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['a90210']

package_data = \
{'': ['*']}

install_requires = \
['maya>=0.6.1,<0.7.0', 'pkginfo>=1.9.6,<2.0.0']

setup_kwargs = {
    'name': 'a90210',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'pboisver',
    'author_email': 'pboisver@umich.edu',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
